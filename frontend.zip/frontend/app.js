// API Configuration
const API_BASE_URL = 'http://localhost:8080'; // Update this with your API Gateway URL

// DOM Elements
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const dashboard = document.getElementById('dashboard');
const loginBtn = document.getElementById('loginBtn');
const registerBtn = document.getElementById('registerBtn');
const loginBtnContainer = document.getElementById('loginBtnContainer');
const registerBtnContainer = document.getElementById('registerBtnContainer');
const profileSection = document.getElementById('profileSection');
const profileName = document.getElementById('profileName');
const profileEmail = document.getElementById('profileEmail');
const logoutBtn = document.getElementById('logoutBtn');
const transactionBtn = document.getElementById('transactionBtn');
const loginFormElement = document.getElementById('loginFormElement');
const registerFormElement = document.getElementById('registerFormElement');
const transactionsList = document.getElementById('transactionsList');
const transactionModal = document.getElementById('transactionModal');
const depositForm = document.getElementById('depositForm');
const withdrawalForm = document.getElementById('withdrawalForm');
const transferForm = document.getElementById('transferForm');
const depositAccountId = document.getElementById('depositAccountId');
const withdrawalAccountId = document.getElementById('withdrawalAccountId');
const sourceAccountNumber = document.getElementById('sourceAccountNumber');
const destinationAccountNumber = document.getElementById('destinationAccountNumber');

// Event Listeners
loginBtn.addEventListener('click', () => {
    loginForm.classList.remove('d-none');
    registerForm.classList.add('d-none');
    dashboard.classList.add('d-none');
});

registerBtn.addEventListener('click', () => {
    registerForm.classList.remove('d-none');
    loginForm.classList.add('d-none');
    dashboard.classList.add('d-none');
});

logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    showLoginRegister();
    loginBtn.click();
});

loginFormElement.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const response = await fetch(`${API_BASE_URL}/api/users/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });

        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('token', data.token);
            localStorage.setItem('userId', data.userId);
            showDashboard();
            loadDashboardData();
            loadUserProfile();
        } else {
            alert('Login failed. Please check your credentials.');
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('An error occurred during login.');
    }
});

registerFormElement.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;

    try {
        const response = await fetch(`${API_BASE_URL}/api/users/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, email, password }),
        });

        if (response.ok) {
            alert('Registration successful! Please login.');
            loginBtn.click();
        } else {
            alert('Registration failed. Please try again.');
        }
    } catch (error) {
        console.error('Registration error:', error);
        alert('An error occurred during registration.');
    }
});

transactionBtn.addEventListener('click', () => {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    
    if (!token || !userId) {
        alert('Please login to perform transactions.');
        return;
    }
    
    // Load user accounts for the dropdowns
    loadUserAccounts();
    
    // Show the transaction modal
    const modal = new bootstrap.Modal(transactionModal);
    modal.show();
});

// Handle deposit form submission
depositForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const token = localStorage.getItem('token');
    if (!token) {
        alert('Please login to perform transactions.');
        return;
    }
    
    const accountId = parseInt(depositAccountId.value);
    const amount = parseFloat(document.getElementById('depositAmount').value);
    const description = document.getElementById('depositDescription').value || null;
    
    if (!accountId || isNaN(amount) || amount <= 0) {
        alert('Please fill in all required fields correctly.');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/transactions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                accountId: accountId,
                amount: amount,
                description: description,
                transactionType: {
                    typeName: "DEPOSIT"
                }
            })
        });
        
        if (response.ok) {
            const result = await response.json();
            alert('Deposit successful!');
            // Close the modal
            const modal = bootstrap.Modal.getInstance(transactionModal);
            modal.hide();
            // Reset the form
            depositForm.reset();
            // Reload dashboard data
            loadDashboardData();
        } else {
            const error = await response.json();
            alert(error.message || 'Failed to process deposit. Please try again.');
        }
    } catch (error) {
        console.error('Error processing deposit:', error);
        alert('An error occurred while processing your deposit. Please try again.');
    }
});

// Handle withdrawal form submission
withdrawalForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const token = localStorage.getItem('token');
    if (!token) {
        alert('Please login to perform transactions.');
        return;
    }
    
    const accountId = parseInt(withdrawalAccountId.value);
    const amount = parseFloat(document.getElementById('withdrawalAmount').value);
    const description = document.getElementById('withdrawalDescription').value || null;
    
    if (!accountId || isNaN(amount) || amount <= 0) {
        alert('Please fill in all required fields correctly.');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/transactions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                accountId: accountId,
                amount: amount, // Send positive amount
                description: description,
                transactionType: {
                    typeName: "WITHDRAWAL"
                }
            })
        });
        
        if (response.ok) {
            const result = await response.json();
            alert('Withdrawal successful!');
            // Close the modal
            const modal = bootstrap.Modal.getInstance(transactionModal);
            modal.hide();
            // Reset the form
            withdrawalForm.reset();
            // Reload dashboard data
            loadDashboardData();
        } else {
            const error = await response.json();
            alert(error.message || 'Failed to process withdrawal. Please try again.');
        }
    } catch (error) {
        console.error('Error processing withdrawal:', error);
        alert('An error occurred while processing your withdrawal. Please try again.');
    }
});

// Handle transfer form submission
transferForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const token = localStorage.getItem('token');
    if (!token) {
        alert('Please login to perform transactions.');
        return;
    }
    
    const sourceAcc = sourceAccountNumber.value;
    const destAcc = destinationAccountNumber.value;
    const amount = parseFloat(document.getElementById('transferAmount').value);
    
    if (!sourceAcc || !destAcc || isNaN(amount) || amount <= 0) {
        alert('Please fill in all required fields correctly.');
        return;
    }
    
    if (sourceAcc === destAcc) {
        alert('Source and destination accounts cannot be the same.');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/transactions/transfer`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                amount: amount,
                sourceAccountNumber: sourceAcc,
                destinationAccountNumber: destAcc
            })
        });
        
        if (response.ok) {
            const result = await response.json();
            alert('Transfer successful!');
            // Close the modal
            const modal = bootstrap.Modal.getInstance(transactionModal);
            modal.hide();
            // Reset the form
            transferForm.reset();
            // Reload dashboard data
            loadDashboardData();
        } else {
            const error = await response.json();
            alert(error.message || 'Failed to process transfer. Please try again.');
        }
    } catch (error) {
        console.error('Error processing transfer:', error);
        alert('An error occurred while processing your transfer. Please try again.');
    }
});

// Function to load user accounts for the dropdowns
async function loadUserAccounts() {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    
    if (!token || !userId) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/accounts/user/${userId}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.ok) {
            const accounts = await response.json();
            
            // Clear existing options
            depositAccountId.innerHTML = '<option value="">Select account</option>';
            withdrawalAccountId.innerHTML = '<option value="">Select account</option>';
            sourceAccountNumber.innerHTML = '<option value="">Select account</option>';
            destinationAccountNumber.innerHTML = '<option value="">Select account</option>';
            
            // Add accounts to all dropdowns
            accounts.forEach(account => {
                if (account.active) {
                    const depositOption = document.createElement('option');
                    depositOption.value = account.accountId;
                    depositOption.textContent = `${account.accountNumber} (${account.accountType}) - $${account.balance.toFixed(2)}`;
                    depositAccountId.appendChild(depositOption);
                    
                    const withdrawalOption = document.createElement('option');
                    withdrawalOption.value = account.accountId;
                    withdrawalOption.textContent = `${account.accountNumber} (${account.accountType}) - $${account.balance.toFixed(2)}`;
                    withdrawalAccountId.appendChild(withdrawalOption);
                    
                    const sourceOption = document.createElement('option');
                    sourceOption.value = account.accountNumber;
                    sourceOption.textContent = `${account.accountNumber} (${account.accountType}) - $${account.balance.toFixed(2)}`;
                    sourceAccountNumber.appendChild(sourceOption);
                    
                    const destOption = document.createElement('option');
                    destOption.value = account.accountNumber;
                    destOption.textContent = `${account.accountNumber} (${account.accountType}) - $${account.balance.toFixed(2)}`;
                    destinationAccountNumber.appendChild(destOption);
                }
            });
        } else {
            console.error('Failed to load user accounts');
        }
    } catch (error) {
        console.error('Error loading user accounts:', error);
    }
}

// Dashboard Functions
async function loadDashboardData() {
    const token = localStorage.getItem('token');
    if (!token) {
        loginBtn.click();
        return;
    }

    try {
        // Fetch recent transactions
        const transactionsResponse = await fetch(`${API_BASE_URL}/api/transactions`, {
            headers: {
                'Authorization': `Bearer ${token}`,
            },
        });

        if (transactionsResponse.ok) {
            const transactions = await transactionsResponse.json();
            displayTransactions(transactions);
        }
    } catch (error) {
        console.error('Dashboard data loading error:', error);
        alert('Error loading dashboard data.');
    }
}

function displayTransactions(transactions) {
    transactionsList.innerHTML = '';
    transactions.forEach(transaction => {
        const row = document.createElement('tr');
        const date = new Date(transaction.timestamp).toLocaleString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        const amount = transaction.amount.toFixed(2);
        const amountClass = transaction.amount >= 0 ? 'amount-positive' : 'amount-negative';
        const statusClass = getStatusClass(transaction.status);
        const typeName = transaction.transactionType ? transaction.transactionType.typeName : 'N/A';
        
        row.innerHTML = `
            <td>${date}</td>
            <td>${transaction.description || 'N/A'}</td>
            <td>${typeName}</td>
            <td><span class="badge ${statusClass}">${transaction.status}</span></td>
            <td class="${amountClass}">$${amount}</td>
        `;
        transactionsList.appendChild(row);
    });
}

function getStatusClass(status) {
    switch (status.toLowerCase()) {
        case 'completed':
            return 'bg-success';
        case 'pending':
            return 'bg-warning';
        case 'failed':
            return 'bg-danger';
        default:
            return 'bg-secondary';
    }
}

function showDashboard() {
    loginForm.classList.add('d-none');
    registerForm.classList.add('d-none');
    dashboard.classList.remove('d-none');
    dashboard.classList.add('fade-in');
    showProfileSection();
}

async function loadUserProfile() {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    
    if (!token || !userId) {
        showLoginRegister();
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/api/users/${userId}`, {
            headers: {
                'Authorization': `Bearer ${token}`,
            },
        });

        if (response.ok) {
            const userData = await response.json();
            profileName.textContent = userData.name;
            profileEmail.textContent = userData.email;
            showProfileSection();
        } else {
            console.error('Failed to load user profile');
            showLoginRegister();
        }
    } catch (error) {
        console.error('Error loading user profile:', error);
        showLoginRegister();
    }
}

function showProfileSection() {
    profileSection.classList.remove('d-none');
    loginBtnContainer.classList.add('d-none');
    registerBtnContainer.classList.add('d-none');
}

function showLoginRegister() {
    profileSection.classList.add('d-none');
    loginBtnContainer.classList.remove('d-none');
    registerBtnContainer.classList.remove('d-none');
}

// Check if user is already logged in
function checkAuthStatus() {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    if (token && userId) {
        showDashboard();
        loadDashboardData();
        loadUserProfile();
    } else {
        showLoginRegister();
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    checkAuthStatus();
}); 