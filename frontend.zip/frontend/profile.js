// API Configuration
const API_BASE_URL = 'http://localhost:8080';

// DOM Elements
const profileName = document.getElementById('profileName');
const profileEmail = document.getElementById('profileEmail');
const profileNameDisplay = document.getElementById('profileNameDisplay');
const profileEmailDisplay = document.getElementById('profileEmailDisplay');
const memberSince = document.getElementById('memberSince');
const logoutBtn = document.getElementById('logoutBtn');
const confirmDeleteAccountsBtn = document.getElementById('confirmDeleteAccountsBtn');
const deleteAccountsModal = document.getElementById('deleteAccountsModal');
const confirmCreateAccountBtn = document.getElementById('confirmCreateAccountBtn');
const createAccountModal = document.getElementById('createAccountModal');
const createAccountForm = document.getElementById('createAccountForm');
const accountsTableBody = document.getElementById('accountsTableBody');
const accountCount = document.getElementById('accountCount');

// Event Listeners
logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    window.location.href = 'index.html';
});

confirmDeleteAccountsBtn.addEventListener('click', async () => {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    
    if (!token || !userId) {
        window.location.href = 'index.html';
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/accounts/user/${userId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.ok) {
            const result = await response.json();
            alert(`Successfully deleted ${result.deletedCount} account(s).`);
            // Close the modal
            const modal = bootstrap.Modal.getInstance(deleteAccountsModal);
            modal.hide();
            // Reload accounts
            loadUserAccounts();
        } else {
            const error = await response.json();
            alert(error.message || 'Failed to delete accounts. Please try again.');
        }
    } catch (error) {
        console.error('Error deleting accounts:', error);
        alert('An error occurred while deleting your accounts. Please try again.');
    }
});

confirmCreateAccountBtn.addEventListener('click', async () => {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    
    if (!token || !userId) {
        window.location.href = 'index.html';
        return;
    }
    
    const accountNumber = document.getElementById('accountNumber').value;
    const accountType = document.getElementById('accountType').value;
    const balance = parseFloat(document.getElementById('balance').value);
    
    if (!accountNumber || !accountType || isNaN(balance)) {
        alert('Please fill in all fields correctly.');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/accounts`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                accountNumber: accountNumber,
                balance: balance,
                accountType: accountType,
                userId: parseInt(userId)
            })
        });
        
        if (response.ok) {
            const result = await response.json();
            alert('Account created successfully!');
            // Close the modal
            const modal = bootstrap.Modal.getInstance(createAccountModal);
            modal.hide();
            // Reset the form
            createAccountForm.reset();
            // Reload accounts
            loadUserAccounts();
        } else {
            const error = await response.json();
            alert(error.message || 'Failed to create account. Please try again.');
        }
    } catch (error) {
        console.error('Error creating account:', error);
        alert('An error occurred while creating your account. Please try again.');
    }
});

async function loadUserProfile() {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    
    if (!token || !userId) {
        window.location.href = 'index.html';
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/api/users/${userId}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const userData = await response.json();
            
            // Update profile information
            const userName = userData.username || 'User';
            profileName.textContent = userName;
            profileEmail.textContent = userData.email;
            profileNameDisplay.textContent = userName;
            profileEmailDisplay.textContent = userData.email;
            
            // Format and display member since date
            const memberSinceDate = new Date(userData.createdAt);
            memberSince.textContent = memberSinceDate.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        } else {
            console.error('Failed to load user profile');
            window.location.href = 'index.html';
        }
    } catch (error) {
        console.error('Error loading user profile:', error);
        window.location.href = 'index.html';
    }
}

async function loadUserAccounts() {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    
    if (!token || !userId) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/api/accounts/user/${userId}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (response.ok) {
            const accounts = await response.json();
            
            // Update account count
            accountCount.textContent = `${accounts.length} account${accounts.length !== 1 ? 's' : ''}`;
            
            // Clear the table body
            accountsTableBody.innerHTML = '';
            
            if (accounts.length === 0) {
                accountsTableBody.innerHTML = `
                    <tr>
                        <td colspan="4" class="text-center">You don't have any accounts yet.</td>
                    </tr>
                `;
                return;
            }
            
            // Add each account to the table
            accounts.forEach(account => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${account.accountNumber}</td>
                    <td>${account.accountType}</td>
                    <td>$${account.balance.toFixed(2)}</td>
                    <td>
                        <span class="badge ${account.active ? 'bg-success' : 'bg-danger'}">
                            ${account.active ? 'Active' : 'Inactive'}
                        </span>
                    </td>
                `;
                accountsTableBody.appendChild(row);
            });
        } else {
            console.error('Failed to load user accounts');
            accountsTableBody.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center text-danger">Failed to load accounts. Please try again later.</td>
                </tr>
            `;
        }
    } catch (error) {
        console.error('Error loading user accounts:', error);
        accountsTableBody.innerHTML = `
            <tr>
                <td colspan="4" class="text-center text-danger">An error occurred while loading your accounts.</td>
            </tr>
        `;
    }
}

// Check authentication and load profile and accounts
document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    
    if (!token || !userId) {
        window.location.href = 'index.html';
        return;
    }
    
    loadUserProfile();
    loadUserAccounts();
}); 