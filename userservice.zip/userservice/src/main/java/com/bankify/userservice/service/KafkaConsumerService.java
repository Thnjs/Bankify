package com.bankify.userservice.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

/**
 * Service for consuming Kafka messages
 */
@Service
public class KafkaConsumerService {
    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerService.class);
    
    private final UserService userService;
    private final ObjectMapper objectMapper;
    
    @Autowired
    public KafkaConsumerService(UserService userService, ObjectMapper objectMapper) {
        this.userService = userService;
        this.objectMapper = objectMapper;
    }
    
    /**
     * Listen for account created events
     * 
     * @param event The event received
     */
    /**
     * Helper method to clean JSON string that might be wrapped in quotes and escaped
     * @param rawJson the raw JSON string that might be wrapped in quotes
     * @return cleaned JSON string
     */
    private String cleanJsonString(String rawJson) {
        if (rawJson == null || rawJson.trim().isEmpty()) {
            return rawJson;
        }
        
        String jsonStr = rawJson;
        if (rawJson.startsWith("\"") && rawJson.endsWith("\"")) {
            // Remove the outer quotes and unescape the inner quotes
            jsonStr = rawJson.substring(1, rawJson.length() - 1).replace("\\\"", "\"");
        }
        return jsonStr;
    }
    
    @KafkaListener(topics = "${kafka.topics.account-created}", groupId = "${spring.kafka.consumer.group-id}")
    public void consumeAccountCreatedEvent(String event) {
        logger.info("Consumed account created event: {}", event);
        try {
            // First, validate that we have a valid JSON
            if (event == null || event.trim().isEmpty()) {
                logger.error("Received empty or null account created event");
                return;
            }
            
            // Clean the JSON string
            String jsonStr = cleanJsonString(event);
            
            JsonNode eventNode = objectMapper.readTree(jsonStr);
            
            // Extract and validate required fields with detailed error messages
            Long userId = null;
            String accountNumber = null;
            
            try {
                JsonNode userIdNode = eventNode.get("userId");
                if (userIdNode == null || userIdNode.isNull()) {
                    logger.error("userId field is missing or null in the event: {}", jsonStr);
                    return;
                }
                userId = userIdNode.asLong();
            } catch (Exception e) {
                logger.error("Error extracting userId from event: {}. Error: {}", jsonStr, e.getMessage());
                return;
            }
            
            try {
                JsonNode accountNumberNode = eventNode.get("accountNumber");
                if (accountNumberNode == null || accountNumberNode.isNull()) {
                    logger.error("accountNumber field is missing or null in the event: {}", jsonStr);
                    return;
                }
                accountNumber = accountNumberNode.asText();
            } catch (Exception e) {
                logger.error("Error extracting accountNumber from event: {}. Error: {}", jsonStr, e.getMessage());
                return;
            }
            
            // Update user with account information
            userService.updateUserWithAccountInfo(userId, accountNumber);
            logger.info("Successfully updated user {} with account information {}", userId, accountNumber);
        } catch (JsonProcessingException e) {
            logger.error("Error processing account created event JSON: {}", e.getMessage());
        } catch (Exception e) {
            logger.error("Error updating user with account information: {}", e.getMessage());
            // Log the full stack trace for debugging
            logger.debug("Full exception details:", e);
        }
    }
    
    /**
     * Listen for transaction completed events
     * 
     * @param event The event received
     */
    @KafkaListener(topics = "${kafka.topics.transaction-completed}", groupId = "${spring.kafka.consumer.group-id}")
    public void consumeTransactionCompletedEvent(String event) {
        logger.info("Consumed transaction completed event: {}", event);
        try {
            // First, validate that we have a valid JSON
            if (event == null || event.trim().isEmpty()) {
                logger.error("Received empty or null transaction completed event");
                return;
            }
            
            // Clean the JSON string
            String jsonStr = cleanJsonString(event);
            
            // Parse the event for validation
            JsonNode eventNode = objectMapper.readTree(jsonStr);
            
            // Extract transaction ID for logging if available
            String transactionId = "unknown";
            JsonNode transactionIdNode = eventNode.get("transactionId");
            if (transactionIdNode != null && !transactionIdNode.isNull()) {
                transactionId = transactionIdNode.asText();
            }
            
            logger.info("Successfully processed transaction completed event for transaction: {}", transactionId);
            
            // This is just for logging purposes in this service
            // You could add more logic here if needed
        } catch (JsonProcessingException e) {
            logger.error("Error processing transaction completed event JSON: {}", e.getMessage());
        } catch (Exception e) {
            logger.error("Error handling transaction completed event: {}", e.getMessage());
        }
    }
}
