package com.bankify.userservice.service;

import com.bankify.userservice.entity.User;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Service for producing Kafka messages
 */
@Service
public class KafkaProducerService {
    private static final Logger logger = LoggerFactory.getLogger(KafkaProducerService.class);
    
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;
    
    @Value("${kafka.topics.user-created}")
    private String userCreatedTopic;
    
    @Value("${kafka.topics.user-updated}")
    private String userUpdatedTopic;
    
    @Value("${kafka.topics.user-deleted}")
    private String userDeletedTopic;
    
    @Autowired
    public KafkaProducerService(KafkaTemplate<String, String> kafkaTemplate, ObjectMapper objectMapper) {
        this.kafkaTemplate = kafkaTemplate;
        this.objectMapper = objectMapper;
    }
    
    /**
     * Send user created event
     * 
     * @param user The user that was created
     */
    public void sendUserCreatedEvent(User user) {
        try {
            Map<String, Object> event = new HashMap<>();
            event.put("userId", user.getUserId());
            event.put("username", user.getUsername());
            event.put("email", user.getEmail());
            event.put("timestamp", LocalDateTime.now().toString());
            event.put("eventType", "USER_CREATED");
            
            String message = objectMapper.writeValueAsString(event);
            kafkaTemplate.send(userCreatedTopic, user.getUserId().toString(), message);
            logger.info("User created event sent for user: {}", user.getUserId());
        } catch (JsonProcessingException e) {
            logger.error("Error sending user created event: {}", e.getMessage());
        }
    }
    
    /**
     * Send user updated event
     * 
     * @param user The user that was updated
     */
    public void sendUserUpdatedEvent(User user) {
        try {
            Map<String, Object> event = new HashMap<>();
            event.put("userId", user.getUserId());
            event.put("username", user.getUsername());
            event.put("email", user.getEmail());
            event.put("timestamp", LocalDateTime.now().toString());
            event.put("eventType", "USER_UPDATED");
            
            String message = objectMapper.writeValueAsString(event);
            kafkaTemplate.send(userUpdatedTopic, user.getUserId().toString(), message);
            logger.info("User updated event sent for user: {}", user.getUserId());
        } catch (JsonProcessingException e) {
            logger.error("Error sending user updated event: {}", e.getMessage());
        }
    }
    
    /**
     * Send user deleted event
     * 
     * @param userId The ID of the user that was deleted
     * @param username The username of the user that was deleted
     */
    public void sendUserDeletedEvent(Long userId, String username) {
        try {
            Map<String, Object> event = new HashMap<>();
            event.put("userId", userId);
            event.put("username", username);
            event.put("timestamp", LocalDateTime.now().toString());
            event.put("eventType", "USER_DELETED");
            
            String message = objectMapper.writeValueAsString(event);
            kafkaTemplate.send(userDeletedTopic, userId.toString(), message);
            logger.info("User deleted event sent for user: {}", userId);
        } catch (JsonProcessingException e) {
            logger.error("Error sending user deleted event: {}", e.getMessage());
        }
    }
}
