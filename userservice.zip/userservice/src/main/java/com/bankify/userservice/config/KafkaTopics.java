package com.bankify.userservice.config;

/**
 * Constants for Kafka topics used in the application
 */
public class KafkaTopics {
    // User-related topics
    public static final String USER_CREATED = "user-created";
    public static final String USER_UPDATED = "user-updated";
    public static final String USER_DELETED = "user-deleted";
    
    // Account-related topics that userservice listens to
    public static final String ACCOUNT_CREATED = "account-created";
    public static final String ACCOUNT_UPDATED = "account-updated";
    public static final String ACCOUNT_DELETED = "account-deleted";
    
    // Transaction-related topics that userservice listens to
    public static final String TRANSACTION_CREATED = "transaction-created";
    
    // Prevent instantiation
    private KafkaTopics() {}
}
