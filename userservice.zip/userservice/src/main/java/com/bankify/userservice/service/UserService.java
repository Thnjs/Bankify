package com.bankify.userservice.service;

import com.bankify.userservice.entity.User;
import com.bankify.userservice.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class UserService {
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    private final UserRepository userRepository;
    private final RestTemplate restTemplate;
    private final KafkaProducerService kafkaProducerService;

    @Autowired
    public UserService(UserRepository userRepository, RestTemplate restTemplate, KafkaProducerService kafkaProducerService) {
        this.userRepository = userRepository;
        this.restTemplate = restTemplate;
        this.kafkaProducerService = kafkaProducerService;
    }

    @Transactional
    public User createUser(User user) {
        // Check if a user with the same email already exists
        User existingUser = userRepository.findByEmail(user.getEmail());
        if (existingUser != null) {
            logger.error("User with email {} already exists", user.getEmail());
            throw new IllegalArgumentException("User with this email already exists");
        }

        User savedUser = userRepository.save(user);

        // Publish user created event
        kafkaProducerService.sendUserCreatedEvent(savedUser);
        logger.info("User created and event published: {}", savedUser.getUserId());

        return savedUser;
    }

    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public List<?> getUserAccounts(Long userId) {
        String url = "http://accountservice/api/accounts/user/" + userId;
        return restTemplate.getForObject(url, List.class);
    }

    /**
     * Update a user
     *
     * @param id The user ID
     * @param user The updated user data
     * @return The updated user
     */
    @Transactional
    public User updateUser(Long id, User user) {
        User existingUser = getUserById(id);
        if (existingUser != null) {
            existingUser.setUsername(user.getUsername());
            existingUser.setEmail(user.getEmail());
            existingUser.setPassword(user.getPassword());

            User updatedUser = userRepository.save(existingUser);

            // Publish user updated event
            kafkaProducerService.sendUserUpdatedEvent(updatedUser);
            logger.info("User updated and event published: {}", updatedUser.getUserId());

            return updatedUser;
        }
        return null;
    }

    /**
     * Delete a user
     *
     * @param id The user ID
     */
    @Transactional
    public void deleteUser(Long id) {
        User user = getUserById(id);
        if (user != null) {
            userRepository.deleteById(id);

            // Publish user deleted event
            kafkaProducerService.sendUserDeletedEvent(id, user.getUsername());
            logger.info("User deleted and event published: {}", id);
        }
    }

    /**
     * Update user with account information
     *
     * @param userId The user ID
     * @param accountNumber The account number
     */
    @Transactional
    public void updateUserWithAccountInfo(Long userId, String accountNumber) {
        User user = getUserById(userId);
        if (user != null) {
            // You could store account information in the user entity if needed
            // For now, we'll just log it
            logger.info("User {} associated with account {}", userId, accountNumber);
        } else {
            logger.error("User not found with ID: {}", userId);
        }
    }
    public User loginUser(String email, String password) {
        User user = userRepository.findByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null; // or throw an exception
    }
}
