package com.bankify.userservice.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application-kafka.properties")
public class KafkaConfig {
    // This class serves as a marker for Kafka configuration
}
