package com.bankify.userservice.config;

import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaAdmin;

import java.util.HashMap;
import java.util.Map;


@Configuration
public class KafkaTopicConfig {

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Value("${kafka.topics.user-created}")
    private String userCreatedTopic;
    
    @Value("${kafka.topics.user-updated}")
    private String userUpdatedTopic;
    
    @Value("${kafka.topics.user-deleted}")
    private String userDeletedTopic;
    
    @Value("${kafka.topics.account-created}")
    private String accountCreatedTopic;
    
    @Value("${kafka.topics.account-updated}")
    private String accountUpdatedTopic;
    
    @Value("${kafka.topics.account-deleted}")
    private String accountDeletedTopic;
    
    @Value("${kafka.topics.transaction-created}")
    private String transactionCreatedTopic;
    
    @Value("${kafka.topics.transaction-completed}")
    private String transactionCompletedTopic;

    /**
     * KafkaAdmin bean to create topics
     */
    @Bean
    public KafkaAdmin kafkaAdmin() {
        Map<String, Object> configs = new HashMap<>();
        configs.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        return new KafkaAdmin(configs);
    }

    /**
     * Create user-created topic
     */
    @Bean
    public NewTopic userCreatedTopic() {
        return TopicBuilder.name(userCreatedTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }

    /**
     * Create user-updated topic
     */
    @Bean
    public NewTopic userUpdatedTopic() {
        return TopicBuilder.name(userUpdatedTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }

    /**
     * Create user-deleted topic
     */
    @Bean
    public NewTopic userDeletedTopic() {
        return TopicBuilder.name(userDeletedTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }

    /**
     * Create account-created topic
     */
    @Bean
    public NewTopic accountCreatedTopic() {
        return TopicBuilder.name(accountCreatedTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }

    /**
     * Create account-updated topic
     */
    @Bean
    public NewTopic accountUpdatedTopic() {
        return TopicBuilder.name(accountUpdatedTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }

    /**
     * Create account-deleted topic
     */
    @Bean
    public NewTopic accountDeletedTopic() {
        return TopicBuilder.name(accountDeletedTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }

    /**
     * Create transaction-created topic
     */
    @Bean
    public NewTopic transactionCreatedTopic() {
        return TopicBuilder.name(transactionCreatedTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }

    /**
     * Create transaction-completed topic
     */
    @Bean
    public NewTopic transactionCompletedTopic() {
        return TopicBuilder.name(transactionCompletedTopic)
                .partitions(3)
                .replicas(1)
                .build();
    }
}
