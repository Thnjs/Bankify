-- Script to verify transactions in the PostgreSQL database

-- Check if the transactions table exists
SELECT EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'transactions'
);

-- Count all transactions
SELECT COUNT(*) FROM transactions;

-- Show the most recent transactions
SELECT 
    transaction_id,
    account_id,
    amount,
    description,
    timestamp,
    created_at,
    active,
    status,
    source_account_number,
    destination_account_number,
    transaction_type_id
FROM 
    transactions
ORDER BY 
    created_at DESC
LIMIT 10;

-- Show transactions by status
SELECT 
    status,
    COUNT(*) as count
FROM 
    transactions
GROUP BY 
    status;

-- Show transfer transactions
SELECT 
    transaction_id,
    amount,
    source_account_number,
    destination_account_number,
    status,
    created_at
FROM 
    transactions
WHERE 
    source_account_number IS NOT NULL
    AND destination_account_number IS NOT NULL
ORDER BY 
    created_at DESC
LIMIT 10;
