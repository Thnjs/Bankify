package com.bankify.transactionservice.kafka;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * Configuration for Kafka consumers
 */
@Configuration
@EnableKafka
public class KafkaConsumerConfig {
    
    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerConfig.class);
    
    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;
    
    @Value("${spring.kafka.consumer.group-id}")
    private String groupId;
    
    @Value("${spring.kafka.consumer.auto-offset-reset:earliest}")
    private String autoOffsetReset;
    
    /**
     * Creates a consumer factory for string messages
     * 
     * @return The consumer factory
     */
    @Bean
    public ConsumerFactory<String, String> consumerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        return new DefaultKafkaConsumerFactory<>(props);
    }
    
    /**
     * Creates a Kafka listener container factory
     * 
     * @return The Kafka listener container factory
     */
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        return factory;
    }
    
    /**
     * Creates a consumer factory for JSON messages
     * 
     * @return The JSON consumer factory
     */
    @Bean
    public ConsumerFactory<String, Object> jsonConsumerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        props.put(JsonDeserializer.TRUSTED_PACKAGES, "com.bankify.*");
        return new DefaultKafkaConsumerFactory<>(props, new StringDeserializer(), new JsonDeserializer<>(Object.class, false));
    }
    
    /**
     * Creates a Kafka listener container factory for JSON messages
     * 
     * @return The JSON Kafka listener container factory
     */
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object> jsonKafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, Object> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(jsonConsumerFactory());
        return factory;
    }
    
    /**
     * Test Kafka consumer on startup
     */
    @PostConstruct
    public void testKafkaConsumer() {
        logger.info("Testing Kafka consumer with bootstrap servers: {}, group ID: {}", bootstrapServers, groupId);
        try {
            ConsumerFactory<String, String> factory = consumerFactory();
            logger.info("Kafka consumer factory created successfully");
            
            // Create a test consumer
            org.apache.kafka.clients.consumer.KafkaConsumer<String, String> consumer = 
                    new org.apache.kafka.clients.consumer.KafkaConsumer<>(factory.getConfigurationProperties());
            
            // Subscribe to a test topic
            consumer.subscribe(java.util.Arrays.asList("kafka-connectivity-test"));
            logger.info("Kafka consumer subscribed to test topic");
            
            // Start a thread to consume messages
            Thread consumerThread = new Thread(() -> {
                try {
                    logger.info("Starting Kafka consumer thread");
                    while (true) {
                        org.apache.kafka.clients.consumer.ConsumerRecords<String, String> records = 
                                consumer.poll(java.time.Duration.ofMillis(100));
                        if (!records.isEmpty()) {
                            logger.info("Received {} messages from Kafka", records.count());
                            for (org.apache.kafka.clients.consumer.ConsumerRecord<String, String> record : records) {
                                logger.info("Received message: {}", record.value());
                            }
                        }
                    }
                } catch (Exception e) {
                    logger.error("Error in Kafka consumer thread: {}", e.getMessage(), e);
                }
            });
            consumerThread.setDaemon(true);
            consumerThread.start();
            logger.info("Kafka consumer thread started");
        } catch (Exception e) {
            logger.error("Error testing Kafka consumer: {}", e.getMessage(), e);
        }
    }
}
