package com.bankify.transactionservice.service;

import com.bankify.transactionservice.entity.Transaction;
import com.bankify.transactionservice.entity.TransactionType;
import com.bankify.transactionservice.repository.TransactionRepository;
import com.bankify.transactionservice.repository.TransactionTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.Map;

@Service
public class TransactionService {
    private final TransactionRepository transactionRepository;
    private final TransactionTypeRepository transactionTypeRepository;
    private final RestTemplate restTemplate;
    private final KafkaProducerService kafkaProducerService;

    private static final String ACCOUNT_SERVICE_URL = "http://ACCOUNTSERVICE/api/accounts";

    @Autowired
    public TransactionService(TransactionRepository transactionRepository,
                             TransactionTypeRepository transactionTypeRepository,
                             RestTemplate restTemplate,
                             KafkaProducerService kafkaProducerService) {
        this.transactionRepository = transactionRepository;
        this.transactionTypeRepository = transactionTypeRepository;
        this.restTemplate = restTemplate;
        this.kafkaProducerService = kafkaProducerService;
    }

    @PostConstruct
    public void init() {
        // Ensure default transaction types exist
        ensureTransactionTypeExists("DEPOSIT", "Money deposited into account");
        ensureTransactionTypeExists("WITHDRAWAL", "Money withdrawn from account");
        ensureTransactionTypeExists("TRANSFER", "Money transferred between accounts");
    }

    private void ensureTransactionTypeExists(String typeName, String description) {
        Optional<TransactionType> existingType = transactionTypeRepository.findByTypeName(typeName);
        if (!existingType.isPresent()) {
            TransactionType newType = new TransactionType(typeName, description);
            transactionTypeRepository.save(newType);
            System.out.println("Created transaction type: " + typeName);
        }
    }

    public Transaction createTransaction(Transaction transaction) {
        // Validate transaction
        if (transaction.getAmount() == null || transaction.getAmount() <= 0) {
            throw new IllegalArgumentException("Transaction amount must be positive");
        }

        if (transaction.getAccountId() == null) {
            throw new IllegalArgumentException("Account ID is required");
        }

        // Ensure transaction type exists
        if (transaction.getTransactionType() == null || transaction.getTransactionType().getTypeName() == null) {
            throw new IllegalArgumentException("Transaction type is required");
        }

        // Look up transaction type by name if only the name is provided
        if (transaction.getTransactionType().getTypeId() == null) {
            String typeName = transaction.getTransactionType().getTypeName();
            Optional<TransactionType> type = transactionTypeRepository.findByTypeName(typeName);
            if (!type.isPresent()) {
                throw new IllegalArgumentException("Invalid transaction type: " + typeName);
            }
            transaction.setTransactionType(type.get());
        }

        // Set default values if not provided
        if (transaction.getTimestamp() == null) {
            transaction.setTimestamp(new Date());
        }

        if (transaction.getCreatedAt() == null) {
            transaction.setCreatedAt(new Date());
        }

        if (transaction.getActive() == null) {
            transaction.setActive(true);
        }

        // Set initial status to PENDING
        transaction.setStatus("PENDING");

        // Save the transaction initially as PENDING
        Transaction savedTransaction = transactionRepository.save(transaction);

        try {
            String transactionType = transaction.getTransactionType().getTypeName();
            
            // For withdrawals, check sufficient funds first
            if ("WITHDRAWAL".equals(transactionType)) {
                // Get account number from account service
                String accountUrl = ACCOUNT_SERVICE_URL + "/" + transaction.getAccountId();
                ResponseEntity<Map> accountResponse = restTemplate.getForEntity(accountUrl, Map.class);
                
                if (accountResponse.getStatusCode() != HttpStatus.OK) {
                    savedTransaction.setStatus("FAILED");
                    savedTransaction.setDescription("Account not found");
                    return transactionRepository.save(savedTransaction);
                }
                
                String accountNumber = (String) accountResponse.getBody().get("accountNumber");
                
                // Check if account has sufficient funds
                boolean hasSufficientFunds = checkSufficientFunds(accountNumber, transaction.getAmount());
                if (!hasSufficientFunds) {
                    savedTransaction.setStatus("FAILED");
                    savedTransaction.setDescription("Insufficient funds");
                    return transactionRepository.save(savedTransaction);
                }
                
                // Update account balance (negative amount for withdrawal)
                boolean updateSuccess = updateAccountBalance(accountNumber, -transaction.getAmount());
                if (!updateSuccess) {
                    savedTransaction.setStatus("FAILED");
                    savedTransaction.setDescription("Failed to update account balance");
                    return transactionRepository.save(savedTransaction);
                }
            } 
            // For deposits, update account balance
            else if ("DEPOSIT".equals(transactionType)) {
                // Get account number from account service
                String accountUrl = ACCOUNT_SERVICE_URL + "/" + transaction.getAccountId();
                ResponseEntity<Map> accountResponse = restTemplate.getForEntity(accountUrl, Map.class);
                
                if (accountResponse.getStatusCode() != HttpStatus.OK) {
                    savedTransaction.setStatus("FAILED");
                    savedTransaction.setDescription("Account not found");
                    return transactionRepository.save(savedTransaction);
                }
                
                String accountNumber = (String) accountResponse.getBody().get("accountNumber");
                
                // Update account balance (positive amount for deposit)
                boolean updateSuccess = updateAccountBalance(accountNumber, transaction.getAmount());
                if (!updateSuccess) {
                    savedTransaction.setStatus("FAILED");
                    savedTransaction.setDescription("Failed to update account balance");
                    return transactionRepository.save(savedTransaction);
                }
            }

            // Update transaction status to COMPLETED
            savedTransaction.setStatus("COMPLETED");
            savedTransaction = transactionRepository.save(savedTransaction);

            // Publish to Kafka if needed
            try {
                kafkaProducerService.sendTransaction(savedTransaction);
            } catch (Exception e) {
                System.out.println("Failed to publish transaction to Kafka: " + e.getMessage());
                // Continue processing - don't fail the transaction just because Kafka is down
            }

            return savedTransaction;
        } catch (Exception e) {
            // Handle any unexpected errors
            savedTransaction.setStatus("FAILED");
            savedTransaction.setDescription("Transaction failed: " + e.getMessage());
            return transactionRepository.save(savedTransaction);
        }
    }

    public Transaction createTransfer(Transaction transaction) {
        // Validate transfer
        if (transaction.getAmount() == null || transaction.getAmount() <= 0) {
            throw new IllegalArgumentException("Transfer amount must be positive");
        }

        if (transaction.getSourceAccountNumber() == null || transaction.getSourceAccountNumber().trim().isEmpty()) {
            throw new IllegalArgumentException("Source account number is required");
        }

        if (transaction.getDestinationAccountNumber() == null || transaction.getDestinationAccountNumber().trim().isEmpty()) {
            throw new IllegalArgumentException("Destination account number is required");
        }

        if (transaction.getSourceAccountNumber().equals(transaction.getDestinationAccountNumber())) {
            throw new IllegalArgumentException("Source and destination accounts cannot be the same");
        }

        // Get the TRANSFER transaction type
        Optional<TransactionType> transferType = transactionTypeRepository.findByTypeName("TRANSFER");
        if (!transferType.isPresent()) {
            throw new IllegalStateException("TRANSFER transaction type not found");
        }

        // Set transaction type
        transaction.setTransactionType(transferType.get());

        // Set default values if not provided
        if (transaction.getTimestamp() == null) {
            transaction.setTimestamp(new Date());
        }

        if (transaction.getCreatedAt() == null) {
            transaction.setCreatedAt(new Date());
        }

        if (transaction.getActive() == null) {
            transaction.setActive(true);
        }

        // Set initial status to PENDING
        transaction.setStatus("PENDING");

        // Save the transaction initially as PENDING
        Transaction savedTransaction = transactionRepository.save(transaction);

        try {
            // Check if source account has sufficient funds
            boolean hasSufficientFunds = checkSufficientFunds(transaction.getSourceAccountNumber(), transaction.getAmount());
            if (!hasSufficientFunds) {
                savedTransaction.setStatus("FAILED");
                savedTransaction.setDescription("Insufficient funds");
                return transactionRepository.save(savedTransaction);
            }

            // Deduct from source account
            boolean deductSuccess = updateAccountBalance(transaction.getSourceAccountNumber(), -transaction.getAmount());
            if (!deductSuccess) {
                savedTransaction.setStatus("FAILED");
                savedTransaction.setDescription("Failed to deduct from source account");
                return transactionRepository.save(savedTransaction);
            }

            // Add to destination account
            boolean addSuccess = updateAccountBalance(transaction.getDestinationAccountNumber(), transaction.getAmount());
            if (!addSuccess) {
                // Rollback the deduction from source account
                updateAccountBalance(transaction.getSourceAccountNumber(), transaction.getAmount());
                savedTransaction.setStatus("FAILED");
                savedTransaction.setDescription("Failed to add to destination account");
                return transactionRepository.save(savedTransaction);
            }

            // Update transaction status to COMPLETED
            savedTransaction.setStatus("COMPLETED");
            savedTransaction = transactionRepository.save(savedTransaction);

            // Publish to Kafka if needed
            try {
                kafkaProducerService.sendTransaction(savedTransaction);
            } catch (Exception e) {
                System.out.println("Failed to publish transaction to Kafka: " + e.getMessage());
                // Continue processing - don't fail the transaction just because Kafka is down
            }

            return savedTransaction;
        } catch (Exception e) {
            // Handle any unexpected errors
            savedTransaction.setStatus("FAILED");
            savedTransaction.setDescription("Transfer failed: " + e.getMessage());
            return transactionRepository.save(savedTransaction);
        }
    }

    private boolean checkSufficientFunds(String accountNumber, Double amount) {
        try {
            String url = ACCOUNT_SERVICE_URL + "/number/" + accountNumber + "/hasSufficientFunds?amount=" + amount;
            ResponseEntity<Boolean> response = restTemplate.getForEntity(url, Boolean.class);
            return response.getStatusCode() == HttpStatus.OK && Boolean.TRUE.equals(response.getBody());
        } catch (RestClientException e) {
            System.out.println("Error checking sufficient funds: " + e.getMessage());
            throw new RuntimeException("Failed to check account balance: " + e.getMessage());
        }
    }

    private boolean updateAccountBalance(String accountNumber, Double amount) {
        try {
            String url = ACCOUNT_SERVICE_URL + "/number/" + accountNumber + "/updateBalance?amount=" + amount;
            restTemplate.put(url, null);
            return true; // Assuming success if no exception is thrown
        } catch (RestClientException e) {
            System.out.println("Error updating account balance: " + e.getMessage());
            throw new RuntimeException("Failed to update account balance: " + e.getMessage());
        }
    }

    public Optional<Transaction> getTransactionById(Long id) {
        return transactionRepository.findById(id);
    }

    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }
    
    /**
     * Delete an account by its ID
     * This method will:
     * 1. Check if the account exists in the account service
     * 2. Delete the account from the account service
     * 3. Return true if successful, false otherwise
     * 
     * @param accountId The ID of the account to delete
     * @return boolean indicating if the deletion was successful
     * @throws IllegalArgumentException if the account doesn't exist
     */
    public boolean deleteAccountById(Long accountId) {
        if (accountId == null) {
            throw new IllegalArgumentException("Account ID cannot be null");
        }
        
        try {
            // First check if the account exists
            String accountUrl = ACCOUNT_SERVICE_URL + "/" + accountId;
            ResponseEntity<Map> response = restTemplate.getForEntity(accountUrl, Map.class);
            
            if (response.getStatusCode() != HttpStatus.OK) {
                throw new IllegalArgumentException("Account not found with ID: " + accountId);
            }
            
            // Delete the account
            restTemplate.delete(accountUrl);
            
            return true;
        } catch (RestClientException e) {
            throw new IllegalArgumentException("Failed to delete account: " + e.getMessage());
        }
    }
}
