package com.bankify.transactionservice.entity;

import javax.persistence.*;

@Entity
@Table(name = "transaction_types")
public class TransactionType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long typeId;

    @Column(unique = true)
    private String typeName;

    @Column
    private String description;

    @Column
    private Boolean active;

    // Default constructor
    public TransactionType() {
        this.active = true;
    }

    // Constructor with name
    public TransactionType(String typeName) {
        this.typeName = typeName;
        this.active = true;
    }

    // Constructor with name and description
    public TransactionType(String typeName, String description) {
        this.typeName = typeName;
        this.description = description;
        this.active = true;
    }

    // Getters and Setters
    public Long getTypeId() {
        return typeId;
    }

    public void setTypeId(Long typeId) {
        this.typeId = typeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return "TransactionType{" +
                "typeId=" + typeId +
                ", typeName='" + typeName + '\'' +
                ", description='" + description + '\'' +
                ", active=" + active +
                '}';
    }
}
