package com.bankify.transactionservice.service;

import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.bankify.transactionservice.entity.Transaction;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Service for interacting with AWS Lambda functions
 */
@Service
@Profile("lambda")
public class AwsLambdaService {
    
    private static final Logger logger = LoggerFactory.getLogger(AwsLambdaService.class);
    
    private final AWSLambda awsLambdaClient;
    private final ObjectMapper objectMapper;
    private final KafkaProducerService kafkaProducerService;
    
    @Value("${aws.lambda.transaction-processor-function}")
    private String transactionProcessorFunction;
    
    @Value("${aws.lambda.fraud-detection-function}")
    private String fraudDetectionFunction;
    
    @Value("${aws.region}")
    private String awsRegion;
    
    @Autowired
    public AwsLambdaService(AWSLambda awsLambdaClient, ObjectMapper objectMapper, KafkaProducerService kafkaProducerService) {
        this.awsLambdaClient = awsLambdaClient;
        this.objectMapper = objectMapper;
        this.kafkaProducerService = kafkaProducerService;
        logger.info("AwsLambdaService initialized with region: {}", awsRegion);
        logger.info("Transaction processor function: {}", transactionProcessorFunction);
        logger.info("Fraud detection function: {}", fraudDetectionFunction);
    }
    
    /**
     * Processes a transaction using AWS Lambda
     * 
     * @param transaction The transaction to process
     * @return The processed transaction or null if processing failed
     */
    public Transaction processTransaction(Transaction transaction) {
        try {
            logger.info("Starting Lambda processing for transaction: {}", transaction.getTransactionId());
            logger.info("Using Lambda function: {} in region: {}", transactionProcessorFunction, awsRegion);
            
            // Create request payload
            Map<String, Object> requestPayload = new HashMap<>();
            requestPayload.put("transaction", transaction);
            requestPayload.put("requestId", UUID.randomUUID().toString());
            requestPayload.put("timestamp", System.currentTimeMillis());
            
            String payload = objectMapper.writeValueAsString(requestPayload);
            logger.debug("Lambda request payload: {}", payload);
            
            // Create Lambda invoke request
            InvokeRequest invokeRequest = new InvokeRequest()
                    .withFunctionName(transactionProcessorFunction)
                    .withPayload(ByteBuffer.wrap(payload.getBytes(StandardCharsets.UTF_8)));
            
            logger.info("Invoking Lambda function: {} with request ID: {}", 
                    transactionProcessorFunction, requestPayload.get("requestId"));
            
            // Invoke Lambda function
            InvokeResult invokeResult = awsLambdaClient.invoke(invokeRequest);
            
            logger.info("Lambda invocation completed with status code: {}", invokeResult.getStatusCode());
            if (invokeResult.getFunctionError() != null) {
                logger.error("Lambda function error: {}", invokeResult.getFunctionError());
            }
            
            // Check if the invocation was successful
            if (invokeResult.getStatusCode() == 200) {
                logger.info("Successfully invoked Lambda function for transaction: {}", transaction.getTransactionId());
                
                // Process the Lambda response if needed
                String response = new String(invokeResult.getPayload().array(), StandardCharsets.UTF_8);
                logger.info("Lambda response: {}", response);
                
                // Update transaction status
                transaction.setStatus("PROCESSED");
                
                // Publish the processed transaction to Kafka
                kafkaProducerService.publishLambdaTransactionProcessed(transaction);
                logger.info("Published processed transaction to Kafka: {}", transaction.getTransactionId());
                
                return transaction;
            } else {
                logger.error("Failed to invoke Lambda function. Status code: {}, Error: {}", 
                        invokeResult.getStatusCode(), invokeResult.getFunctionError());
                transaction.setStatus("FAILED");
                kafkaProducerService.publishTransactionFailed(transaction);
                return null;
            }
        } catch (JsonProcessingException e) {
            logger.error("Error serializing transaction for Lambda: {}", e.getMessage(), e);
            transaction.setStatus("FAILED");
            kafkaProducerService.publishTransactionFailed(transaction);
            return null;
        } catch (Exception e) {
            logger.error("Error invoking Lambda function: {}", e.getMessage(), e);
            logger.error("Stack trace: ", e);
            transaction.setStatus("FAILED");
            kafkaProducerService.publishTransactionFailed(transaction);
            return null;
        }
    }
    
    /**
     * Detects fraud in a transaction using AWS Lambda
     * 
     * @param transaction The transaction to check for fraud
     * @return True if the transaction is not fraudulent
     */
    public boolean detectFraud(Transaction transaction) {
        try {
            logger.info("Starting fraud detection for transaction: {}", transaction.getTransactionId());
            logger.info("Using Lambda function: {} in region: {}", fraudDetectionFunction, awsRegion);
            
            // Create request payload
            Map<String, Object> requestPayload = new HashMap<>();
            requestPayload.put("transaction", transaction);
            requestPayload.put("requestId", UUID.randomUUID().toString());
            requestPayload.put("timestamp", System.currentTimeMillis());
            
            String payload = objectMapper.writeValueAsString(requestPayload);
            logger.debug("Fraud detection request payload: {}", payload);
            
            // Create Lambda invoke request
            InvokeRequest invokeRequest = new InvokeRequest()
                    .withFunctionName(fraudDetectionFunction)
                    .withPayload(ByteBuffer.wrap(payload.getBytes(StandardCharsets.UTF_8)));
            
            logger.info("Invoking fraud detection Lambda function: {} with request ID: {}", 
                    fraudDetectionFunction, requestPayload.get("requestId"));
            
            // Invoke Lambda function
            InvokeResult invokeResult = awsLambdaClient.invoke(invokeRequest);
            
            logger.info("Fraud detection Lambda invocation completed with status code: {}", invokeResult.getStatusCode());
            if (invokeResult.getFunctionError() != null) {
                logger.error("Fraud detection Lambda function error: {}", invokeResult.getFunctionError());
            }
            
            // Check if the invocation was successful
            if (invokeResult.getStatusCode() == 200) {
                logger.info("Successfully invoked fraud detection Lambda for transaction: {}", transaction.getTransactionId());
                
                // Process the Lambda response
                String response = new String(invokeResult.getPayload().array(), StandardCharsets.UTF_8);
                logger.info("Fraud detection response: {}", response);
                
                Map<String, Object> responseMap = objectMapper.readValue(response, Map.class);
                boolean isFraudulent = Boolean.parseBoolean(responseMap.getOrDefault("isFraudulent", "false").toString());
                
                if (isFraudulent) {
                    logger.warn("Fraud detected for transaction: {}", transaction.getTransactionId());
                    transaction.setStatus("FRAUD_DETECTED");
                    kafkaProducerService.publishTransactionFailed(transaction);
                }
                
                return !isFraudulent;
            } else {
                logger.error("Failed to invoke fraud detection Lambda. Status code: {}, Error: {}", 
                        invokeResult.getStatusCode(), invokeResult.getFunctionError());
                return false;
            }
        } catch (JsonProcessingException e) {
            logger.error("Error serializing transaction for fraud detection: {}", e.getMessage());
            logger.error("Stack trace: ", e);
            return false;
        } catch (Exception e) {
            logger.error("Error invoking fraud detection Lambda: {}", e.getMessage());
            logger.error("Stack trace: ", e);
            return false;
        }
    }
}
