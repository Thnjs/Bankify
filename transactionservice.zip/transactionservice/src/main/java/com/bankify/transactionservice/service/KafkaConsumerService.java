package com.bankify.transactionservice.service;

import com.bankify.transactionservice.entity.Transaction;
import com.bankify.transactionservice.kafka.KafkaTopics;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Service for consuming Kafka messages
 */
@Service
public class KafkaConsumerService {

    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerService.class);

    private final ObjectMapper objectMapper;
    private final AwsLambdaService awsLambdaService;

    @Autowired
    public KafkaConsumerService(ObjectMapper objectMapper, AwsLambdaService awsLambdaService) {
        this.objectMapper = objectMapper;
        this.awsLambdaService = awsLambdaService;
    }

    /**
     * Listens for transaction created events
     *
     * @param message The Kafka message
     */
    @KafkaListener(topics = "#{kafkaTopics.TRANSACTION_CREATED}", groupId = "${spring.kafka.consumer.group-id}")
    public void consumeTransactionCreated(String message) {
        try {
            logger.info("Received transaction created message: {}", message);
            Transaction transaction = objectMapper.readValue(message, Transaction.class);

            // Process the transaction with AWS Lambda
            Transaction processedTransaction = awsLambdaService.processTransaction(transaction);

            if (processedTransaction != null) {
                logger.info("Transaction processed successfully: {}", processedTransaction.getTransactionId());
            } else {
                logger.error("Failed to process transaction: {}", transaction.getTransactionId());
            }
        } catch (JsonProcessingException e) {
            logger.error("Error deserializing transaction message: {}", e.getMessage());
        } catch (Exception e) {
            logger.error("Error processing transaction message: {}", e.getMessage());
        }
    }

    /**
     * Listens for lambda transaction processed events
     *
     * @param message The Kafka message
     */
    @KafkaListener(topics = "#{kafkaTopics.LAMBDA_TRANSACTION_PROCESSED}", groupId = "${spring.kafka.consumer.group-id}")
    public void consumeLambdaTransactionProcessed(String message) {
        try {
            logger.info("Received lambda transaction processed message: {}", message);
            Transaction transaction = objectMapper.readValue(message, Transaction.class);

            // Update transaction status or perform additional processing
            logger.info("Lambda processed transaction: {}", transaction.getTransactionId());
        } catch (JsonProcessingException e) {
            logger.error("Error deserializing lambda transaction processed message: {}", e.getMessage());
        } catch (Exception e) {
            logger.error("Error processing lambda transaction processed message: {}", e.getMessage());
        }
    }

    /**
     * Listens for lambda fraud detected events
     *
     * @param message The Kafka message
     */
    @KafkaListener(topics = "#{kafkaTopics.LAMBDA_FRAUD_DETECTED}", groupId = "${spring.kafka.consumer.group-id}")
    public void consumeLambdaFraudDetected(String message) {
        try {
            logger.info("Received lambda fraud detected message: {}", message);
            Map<String, Object> fraudResult = objectMapper.readValue(message, Map.class);

            Transaction transaction = objectMapper.convertValue(fraudResult.get("transaction"), Transaction.class);
            boolean isFraudulent = (boolean) fraudResult.get("isFraudulent");

            if (isFraudulent) {
                logger.warn("Fraud detected for transaction: {}", transaction.getTransactionId());
                // Handle fraudulent transaction
            } else {
                logger.info("No fraud detected for transaction: {}", transaction.getTransactionId());
                // Process legitimate transaction
            }
        } catch (JsonProcessingException e) {
            logger.error("Error deserializing lambda fraud detected message: {}", e.getMessage());
        } catch (Exception e) {
            logger.error("Error processing lambda fraud detected message: {}", e.getMessage());
        }
    }
}
