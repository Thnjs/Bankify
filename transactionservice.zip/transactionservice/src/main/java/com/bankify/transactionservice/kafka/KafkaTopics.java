package com.bankify.transactionservice.kafka;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Constants for Kafka topic names
 */
@Component
public class KafkaTopics {

    // Transaction topics
    public static String TRANSACTION_CREATED;
    public static String TRANSACTION_COMPLETED;
    public static String TRANSACTION_FAILED;

    // Lambda-related topics
    public static String LAMBDA_TRANSACTION_PROCESSED;
    public static String LAMBDA_FRAUD_DETECTED;

    /**
     * Sets the transaction created topic name
     *
     * @param topicName The topic name from properties
     */
    @Value("${kafka.topic.transactions.created:transaction-created}")
    public void setTransactionCreatedTopic(String topicName) {
        TRANSACTION_CREATED = topicName;
    }

    /**
     * Sets the transaction completed topic name
     *
     * @param topicName The topic name from properties
     */
    @Value("${kafka.topic.transactions.completed:transaction-completed}")
    public void setTransactionCompletedTopic(String topicName) {
        TRANSACTION_COMPLETED = topicName;
    }

    /**
     * Sets the transaction failed topic name
     *
     * @param topicName The topic name from properties
     */
    @Value("${kafka.topic.transactions.failed:transaction-failed}")
    public void setTransactionFailedTopic(String topicName) {
        TRANSACTION_FAILED = topicName;
    }

    /**
     * Sets the lambda transaction processed topic name
     *
     * @param topicName The topic name from properties
     */
    @Value("${kafka.topic.lambda.transaction-processed:lambda-transaction-processed}")
    public void setLambdaTransactionProcessedTopic(String topicName) {
        LAMBDA_TRANSACTION_PROCESSED = topicName;
    }

    /**
     * Sets the lambda fraud detected topic name
     *
     * @param topicName The topic name from properties
     */
    @Value("${kafka.topic.lambda.fraud-detected:lambda-fraud-detected}")
    public void setLambdaFraudDetectedTopic(String topicName) {
        LAMBDA_FRAUD_DETECTED = topicName;
    }
}
