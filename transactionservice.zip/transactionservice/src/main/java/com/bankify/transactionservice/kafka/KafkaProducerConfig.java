package com.bankify.transactionservice.kafka;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * Configuration for Kafka producers
 */
@Configuration
public class KafkaProducerConfig {
    
    private static final Logger logger = LoggerFactory.getLogger(KafkaProducerConfig.class);
    
    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;
    
    /**
     * Creates a producer factory for string messages
     * 
     * @return The producer factory
     */
    @Bean
    public ProducerFactory<String, String> producerFactory() {
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        return new DefaultKafkaProducerFactory<>(configProps);
    }
    
    /**
     * Creates a Kafka template for string messages
     * 
     * @return The Kafka template
     */
    @Bean
    public KafkaTemplate<String, String> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }
    
    /**
     * Creates a producer factory for JSON messages
     * 
     * @return The JSON producer factory
     */
    @Bean
    public ProducerFactory<String, Object> jsonProducerFactory() {
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        return new DefaultKafkaProducerFactory<>(configProps);
    }
    
    /**
     * Creates a Kafka template for JSON messages
     * 
     * @return The JSON Kafka template
     */
    @Bean
    public KafkaTemplate<String, Object> jsonKafkaTemplate() {
        return new KafkaTemplate<>(jsonProducerFactory());
    }
    
    /**
     * Test Kafka connectivity on startup
     */
    @PostConstruct
    public void testKafkaConnectivity() {
        logger.info("Testing Kafka connectivity to bootstrap servers: {}", bootstrapServers);
        try {
            KafkaTemplate<String, String> template = kafkaTemplate();
            template.send("kafka-connectivity-test", "test-message")
                .addCallback(
                    result -> logger.info("Kafka connectivity test successful. Message sent to topic: {}, partition: {}, offset: {}", 
                        result.getRecordMetadata().topic(), result.getRecordMetadata().partition(), result.getRecordMetadata().offset()),
                    ex -> logger.error("Kafka connectivity test failed: {}", ex.getMessage(), ex)
                );
        } catch (Exception e) {
            logger.error("Error testing Kafka connectivity: {}", e.getMessage(), e);
        }
    }
}
