package com.bankify.transactionservice.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "transactions")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;

    @Column
    private Long accountId;

    @Column
    private Double amount;

    @Column
    private String description;

    @Column
    private Date timestamp;

    @Column
    private Date createdAt;

    @Column
    private Boolean active;

    @Column
    private String status;

    @Column
    private String sourceAccountNumber;

    @Column
    private String destinationAccountNumber;

    @ManyToOne
    @JoinColumn(name = "transaction_type_id")
    private TransactionType transactionType;

    // Default constructor
    public Transaction() {
        this.createdAt = new Date();
        this.active = true;
    }

    // Constructor for regular transactions
    public Transaction(Long accountId, Double amount, TransactionType transactionType) {
        Date now = new Date();
        this.accountId = accountId;
        this.amount = amount;
        this.transactionType = transactionType;
        this.createdAt = now;
        this.timestamp = now;
        this.active = true;
        this.status = "COMPLETED";
    }

    // Constructor for transfers
    public Transaction(String sourceAccountNumber, String destinationAccountNumber, Double amount, TransactionType transactionType) {
        Date now = new Date();
        this.sourceAccountNumber = sourceAccountNumber;
        this.destinationAccountNumber = destinationAccountNumber;
        this.amount = amount;
        this.transactionType = transactionType;
        this.createdAt = now;
        this.timestamp = now;
        this.active = true;
        this.status = "PENDING";
    }

    // Getters and Setters
    public Long getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Long transactionId) {
        this.transactionId = transactionId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public TransactionType getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    public String getSourceAccountNumber() {
        return sourceAccountNumber;
    }

    public void setSourceAccountNumber(String sourceAccountNumber) {
        this.sourceAccountNumber = sourceAccountNumber;
    }

    public String getDestinationAccountNumber() {
        return destinationAccountNumber;
    }

    public void setDestinationAccountNumber(String destinationAccountNumber) {
        this.destinationAccountNumber = destinationAccountNumber;
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "transactionId=" + transactionId +
                ", accountId=" + accountId +
                ", amount=" + amount +
                ", description='" + description + '\'' +
                ", timestamp=" + timestamp +
                ", createdAt=" + createdAt +
                ", active=" + active +
                ", status='" + status + '\'' +
                ", sourceAccountNumber='" + sourceAccountNumber + '\'' +
                ", destinationAccountNumber='" + destinationAccountNumber + '\'' +
                ", transactionType=" + (transactionType != null ? transactionType.getTypeName() : "null") +
                '}';
    }
}
