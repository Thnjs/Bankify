package com.bankify.transactionservice.kafka;

import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.NewTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaAdmin;

import java.util.HashMap;
import java.util.Map;

/**
 * Configuration class for Kafka topics
 * This class is responsible for creating Kafka topics if they don't exist
 */
@Configuration
public class KafkaTopicConfig {

    private static final Logger logger = LoggerFactory.getLogger(KafkaTopicConfig.class);

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;
    
    @Autowired
    private KafkaTopics kafkaTopics;

    /**
     * KafkaAdmin bean to create topics
     */
    @Bean
    public KafkaAdmin kafkaAdmin() {
        logger.info("Initializing KafkaAdmin with bootstrap servers: {}", bootstrapServers);
        Map<String, Object> configs = new HashMap<>();
        configs.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        return new KafkaAdmin(configs);
    }

    /**
     * Create transaction-created topic
     */
    @Bean
    public NewTopic transactionCreatedTopic() {
        logger.info("Creating Kafka topic: {}", KafkaTopics.TRANSACTION_CREATED);
        return TopicBuilder.name(KafkaTopics.TRANSACTION_CREATED)
                .partitions(3)
                .replicas(1)
                .build();
    }

    /**
     * Create transaction-completed topic
     */
    @Bean
    public NewTopic transactionCompletedTopic() {
        logger.info("Creating Kafka topic: {}", KafkaTopics.TRANSACTION_COMPLETED);
        return TopicBuilder.name(KafkaTopics.TRANSACTION_COMPLETED)
                .partitions(3)
                .replicas(1)
                .build();
    }

    /**
     * Create transaction-failed topic
     */
    @Bean
    public NewTopic transactionFailedTopic() {
        logger.info("Creating Kafka topic: {}", KafkaTopics.TRANSACTION_FAILED);
        return TopicBuilder.name(KafkaTopics.TRANSACTION_FAILED)
                .partitions(3)
                .replicas(1)
                .build();
    }

    /**
     * Create lambda-transaction-processed topic
     */
    @Bean
    public NewTopic lambdaTransactionProcessedTopic() {
        logger.info("Creating Kafka topic: {}", KafkaTopics.LAMBDA_TRANSACTION_PROCESSED);
        return TopicBuilder.name(KafkaTopics.LAMBDA_TRANSACTION_PROCESSED)
                .partitions(3)
                .replicas(1)
                .build();
    }

    /**
     * Create lambda-fraud-detected topic
     */
    @Bean
    public NewTopic lambdaFraudDetectedTopic() {
        logger.info("Creating Kafka topic: {}", KafkaTopics.LAMBDA_FRAUD_DETECTED);
        return TopicBuilder.name(KafkaTopics.LAMBDA_FRAUD_DETECTED)
                .partitions(3)
                .replicas(1)
                .build();
    }
}
