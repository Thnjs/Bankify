package com.bankify.transactionservice.kafka;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * Configuration for AWS Lambda
 */
@Configuration
@Profile("lambda")
public class AwsLambdaConfig {

    private static final Logger logger = LoggerFactory.getLogger(AwsLambdaConfig.class);

    @Value("${aws.access-key}")
    private String awsAccessKey;

    @Value("${aws.secret-key}")
    private String awsSecretKey;

    @Value("${aws.region}")
    private String awsRegion;

    /**
     * Creates an AWS Lambda client
     * 
     * @return AWSLambda client
     */
    @Bean
    public AWSLambda awsLambdaClient() {
        try {
            logger.info("Initializing AWS Lambda client...");
            logger.info("AWS Region: {}", awsRegion);
            logger.info("AWS Access Key ID is set: {}", awsAccessKey != null && !awsAccessKey.isEmpty());
            logger.info("AWS Secret Key is set: {}", awsSecretKey != null && !awsSecretKey.isEmpty());
            
            if (awsAccessKey == null || awsAccessKey.isEmpty()) {
                throw new IllegalStateException("AWS Access Key is not configured");
            }
            
            if (awsSecretKey == null || awsSecretKey.isEmpty()) {
                throw new IllegalStateException("AWS Secret Key is not configured");
            }
            
            if (awsRegion == null || awsRegion.isEmpty()) {
                throw new IllegalStateException("AWS Region is not configured");
            }
            
            BasicAWSCredentials awsCredentials = new BasicAWSCredentials(awsAccessKey, awsSecretKey);
            
            AWSLambda client = AWSLambdaClientBuilder.standard()
                    .withRegion(Regions.fromName(awsRegion))
                    .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
                    .build();
                    
            logger.info("AWS Lambda client initialized successfully");
            return client;
        } catch (Exception e) {
            logger.error("Failed to initialize AWS Lambda client: {}", e.getMessage());
            logger.error("Stack trace: ", e);
            throw new RuntimeException("Failed to initialize AWS Lambda client", e);
        }
    }
}
