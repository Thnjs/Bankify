package com.bankify.transactionservice.service;

import com.bankify.transactionservice.entity.Transaction;
import com.bankify.transactionservice.kafka.KafkaTopics;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Service for producing Kafka messages
 */
@Service
public class KafkaProducerService {
    
    private static final Logger logger = LoggerFactory.getLogger(KafkaProducerService.class);
    
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;
    
    @Autowired
    public KafkaProducerService(KafkaTemplate<String, String> kafkaTemplate, ObjectMapper objectMapper) {
        this.kafkaTemplate = kafkaTemplate;
        this.objectMapper = objectMapper;
    }
    
    /**
     * Sends a transaction to the transaction-created Kafka topic
     * 
     * @param transaction The transaction to send
     */
    public void sendTransaction(Transaction transaction) {
        try {
            logger.info("Preparing to send transaction to Kafka topic: {}", KafkaTopics.TRANSACTION_CREATED);
            String transactionJson = objectMapper.writeValueAsString(transaction);
            logger.debug("Transaction JSON: {}", transactionJson);
            
            kafkaTemplate.send(KafkaTopics.TRANSACTION_CREATED, String.valueOf(transaction.getTransactionId()), transactionJson)
                .addCallback(
                    result -> logger.info("Transaction successfully sent to Kafka: {}, topic: {}, partition: {}, offset: {}", 
                        transaction.getTransactionId(), result.getRecordMetadata().topic(), 
                        result.getRecordMetadata().partition(), result.getRecordMetadata().offset()),
                    ex -> logger.error("Failed to send transaction to Kafka: {}", ex.getMessage(), ex)
                );
        } catch (Exception e) {
            logger.error("Error sending transaction to Kafka: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to send transaction to Kafka", e);
        }
    }
    
    /**
     * Publishes a transaction to the transaction-completed Kafka topic
     * 
     * @param transaction The completed transaction
     */
    public void publishTransactionCompleted(Transaction transaction) {
        try {
            logger.info("Preparing to publish completed transaction to Kafka topic: {}", KafkaTopics.TRANSACTION_COMPLETED);
            String transactionJson = objectMapper.writeValueAsString(transaction);
            logger.debug("Completed transaction JSON: {}", transactionJson);
            
            kafkaTemplate.send(KafkaTopics.TRANSACTION_COMPLETED, String.valueOf(transaction.getTransactionId()), transactionJson)
                .addCallback(
                    result -> logger.info("Completed transaction successfully sent to Kafka: {}, topic: {}, partition: {}, offset: {}", 
                        transaction.getTransactionId(), result.getRecordMetadata().topic(), 
                        result.getRecordMetadata().partition(), result.getRecordMetadata().offset()),
                    ex -> logger.error("Failed to send completed transaction to Kafka: {}", ex.getMessage(), ex)
                );
        } catch (Exception e) {
            logger.error("Error sending completed transaction to Kafka: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to send transaction completion to Kafka", e);
        }
    }
    
    /**
     * Publishes a transaction to the transaction-failed Kafka topic
     * 
     * @param transaction The failed transaction
     */
    public void publishTransactionFailed(Transaction transaction) {
        try {
            logger.info("Preparing to publish failed transaction to Kafka topic: {}", KafkaTopics.TRANSACTION_FAILED);
            String transactionJson = objectMapper.writeValueAsString(transaction);
            logger.debug("Failed transaction JSON: {}", transactionJson);
            
            kafkaTemplate.send(KafkaTopics.TRANSACTION_FAILED, String.valueOf(transaction.getTransactionId()), transactionJson)
                .addCallback(
                    result -> logger.info("Failed transaction successfully sent to Kafka: {}, topic: {}, partition: {}, offset: {}", 
                        transaction.getTransactionId(), result.getRecordMetadata().topic(), 
                        result.getRecordMetadata().partition(), result.getRecordMetadata().offset()),
                    ex -> logger.error("Failed to send failed transaction to Kafka: {}", ex.getMessage(), ex)
                );
        } catch (Exception e) {
            logger.error("Error sending failed transaction to Kafka: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to send transaction failure to Kafka", e);
        }
    }
    
    /**
     * Publishes a message to the lambda-transaction-processed Kafka topic
     * 
     * @param transaction The processed transaction
     */
    public void publishLambdaTransactionProcessed(Transaction transaction) {
        try {
            logger.info("Preparing to publish Lambda processed transaction to Kafka topic: {}", KafkaTopics.LAMBDA_TRANSACTION_PROCESSED);
            String transactionJson = objectMapper.writeValueAsString(transaction);
            logger.debug("Lambda processed transaction JSON: {}", transactionJson);
            
            kafkaTemplate.send(KafkaTopics.LAMBDA_TRANSACTION_PROCESSED, String.valueOf(transaction.getTransactionId()), transactionJson)
                .addCallback(
                    result -> logger.info("Lambda processed transaction successfully sent to Kafka: {}, topic: {}, partition: {}, offset: {}", 
                        transaction.getTransactionId(), result.getRecordMetadata().topic(), 
                        result.getRecordMetadata().partition(), result.getRecordMetadata().offset()),
                    ex -> logger.error("Failed to send Lambda processed transaction to Kafka: {}", ex.getMessage(), ex)
                );
        } catch (Exception e) {
            logger.error("Error sending lambda processed transaction to Kafka: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to send lambda transaction processing to Kafka", e);
        }
    }
    
    /**
     * Publishes a message to the lambda-fraud-detected Kafka topic
     * 
     * @param transaction The transaction with detected fraud
     * @param isFraudulent Whether fraud was detected
     */
    public void publishFraudDetectionResult(Transaction transaction, boolean isFraudulent) {
        try {
            Map<String, Object> fraudResult = new HashMap<>();
            fraudResult.put("transaction", transaction);
            fraudResult.put("isFraudulent", isFraudulent);
            
            String fraudResultJson = objectMapper.writeValueAsString(fraudResult);
            kafkaTemplate.send(KafkaTopics.LAMBDA_FRAUD_DETECTED, String.valueOf(transaction.getTransactionId()), fraudResultJson);
            logger.info("Fraud detection result sent to Kafka for transaction: {}, isFraudulent: {}", 
                    transaction.getTransactionId(), isFraudulent);
        } catch (Exception e) {
            logger.error("Error sending fraud detection result to Kafka: {}", e.getMessage());
            throw new RuntimeException("Failed to send fraud detection result to Kafka", e);
        }
    }
}
