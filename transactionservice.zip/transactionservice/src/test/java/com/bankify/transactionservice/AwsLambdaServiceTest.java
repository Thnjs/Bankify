package com.bankify.transactionservice;

import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.bankify.transactionservice.entity.Transaction;
import com.bankify.transactionservice.service.AwsLambdaService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * Test class for AwsLambdaService
 */
public class AwsLambdaServiceTest {
    
    @Mock
    private AWSLambda awsLambdaClient;
    
    @Mock
    private ObjectMapper objectMapper;
    
    @InjectMocks
    private AwsLambdaService awsLambdaService;
    
    @BeforeEach
    public void setup() throws Exception {
        MockitoAnnotations.openMocks(this);
        
        ReflectionTestUtils.setField(awsLambdaService, "transactionProcessorFunction", "test-transaction-processor");
        ReflectionTestUtils.setField(awsLambdaService, "fraudDetectionFunction", "test-fraud-detection");
        
        // Mock ObjectMapper
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        when(objectMapper.readValue(any(String.class), any(Class.class))).thenReturn(new Transaction());
    }
    
    @Test
    public void testProcessTransaction() throws Exception {
        // Create a test transaction
        Transaction transaction = new Transaction();
        transaction.setTransactionId(UUID.randomUUID().toString());
        transaction.setAccountId(1L);
        transaction.setAmount(new BigDecimal("100.00"));
        transaction.setType("DEPOSIT");
        transaction.setStatus("PENDING");
        
        // Mock AWS Lambda response
        InvokeResult invokeResult = new InvokeResult();
        invokeResult.setStatusCode(200);
        invokeResult.setPayload(ByteBuffer.wrap("{}".getBytes()));
        
        when(awsLambdaClient.invoke(any(InvokeRequest.class))).thenReturn(invokeResult);
        
        // Call the method
        Transaction result = awsLambdaService.processTransaction(transaction);
        
        // Verify the result
        assertNotNull(result);
    }
    
    @Test
    public void testDetectFraud() throws Exception {
        // Create a test transaction
        Transaction transaction = new Transaction();
        transaction.setTransactionId(UUID.randomUUID().toString());
        transaction.setAccountId(1L);
        transaction.setAmount(new BigDecimal("1000.00"));
        transaction.setType("TRANSFER");
        transaction.setStatus("PENDING");
        
        // Mock AWS Lambda response
        InvokeResult invokeResult = new InvokeResult();
        invokeResult.setStatusCode(200);
        invokeResult.setPayload(ByteBuffer.wrap("{\"isFraudulent\": false}".getBytes()));
        
        when(awsLambdaClient.invoke(any(InvokeRequest.class))).thenReturn(invokeResult);
        when(objectMapper.readValue(any(String.class), any(Class.class))).thenReturn(new FraudDetectionResult(false));
        
        // Call the method
        boolean isFraudulent = awsLambdaService.detectFraud(transaction);
        
        // Verify the result
        assertEquals(false, isFraudulent);
    }
    
    /**
     * Helper class for fraud detection result
     */
    private static class FraudDetectionResult {
        private boolean isFraudulent;
        
        public FraudDetectionResult(boolean isFraudulent) {
            this.isFraudulent = isFraudulent;
        }
        
        public boolean isFraudulent() {
            return isFraudulent;
        }
        
        public void setFraudulent(boolean fraudulent) {
            isFraudulent = fraudulent;
        }
    }
}
