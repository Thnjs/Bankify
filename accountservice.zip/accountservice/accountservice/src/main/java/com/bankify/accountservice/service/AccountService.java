package com.bankify.accountservice.service;

import com.bankify.accountservice.entity.Account;
import com.bankify.accountservice.repository.AccountRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
public class AccountService {
    private static final Logger logger = LoggerFactory.getLogger(AccountService.class);

    private final AccountRepository accountRepository;
    private final KafkaProducerService kafkaProducerService;

    @Autowired
    public AccountService(AccountRepository accountRepository, KafkaProducerService kafkaProducerService) {
        this.accountRepository = accountRepository;
        this.kafkaProducerService = kafkaProducerService;
    }

    public Account createAccount(Account account) {
        Account savedAccount = accountRepository.save(account);
        // Publish account created event
        kafkaProducerService.sendAccountCreatedEvent(savedAccount);
        return savedAccount;
    }

    public Account getAccountById(Long id) {
        return accountRepository.findById(id).orElse(null);
    }

    @Transactional
    public void updateBalance(Long id, Double amount) {
        Account account = getAccountById(id);
        if (account != null) {
            account.setBalance(account.getBalance() + amount);
            accountRepository.save(account);
            // Publish account updated event
            kafkaProducerService.sendAccountUpdatedEvent(account);
        }
    }
    
    public List<Account> getAccountsByUserId(Long userId) {
        return accountRepository.findByUserId(userId);
    }
    
    /**
     * Deletes all accounts associated with a specific user
     * @param userId The ID of the user whose accounts should be deleted
     * @return The number of accounts deleted
     */
    @Transactional
    public int deleteAccountsByUserId(Long userId) {
        List<Account> accounts = getAccountsByUserId(userId);
        if (accounts.isEmpty()) {
            return 0;
        }
        
        // Publish account deleted events for each account
        for (Account account : accounts) {
            kafkaProducerService.sendAccountDeletedEvent(account);
        }
        
        // Delete all accounts
        accountRepository.deleteAll(accounts);
        return accounts.size();
    }
    
    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }
    
    public boolean hasSufficientFunds(Long accountId, Double amount) {
        Account account = getAccountById(accountId);
        return account != null && account.getBalance() >= amount;
    }
    
    public Account getAccountByAccountNumber(String accountNumber) {
        return accountRepository.findByAccountNumber(accountNumber);
    }
    
    public boolean hasSufficientFundsByAccountNumber(String accountNumber, Double amount) {
        Account account = getAccountByAccountNumber(accountNumber);
        return account != null && account.getBalance() >= amount;
    }
    
    @Transactional
    public void updateBalanceByAccountNumber(String accountNumber, Double amount) {
        Account account = getAccountByAccountNumber(accountNumber);
        if (account != null) {
            account.setBalance(account.getBalance() + amount);
            accountRepository.save(account);
            // Publish account updated event
            kafkaProducerService.sendAccountUpdatedEvent(account);
        } else {
            throw new RuntimeException("Account not found with account number: " + accountNumber);
        }
    }
    
    /**
     * Create a default account for a new user
     * 
     * @param userId The user ID
     * @param username The username
     * @return The created account
     */
    @Transactional
    public Account createDefaultAccount(Long userId, String username) {
        Account account = new Account();
        account.setUserId(userId);
        account.setAccountNumber(generateAccountNumber());
        account.setAccountType("SAVINGS");
        account.setBalance(0.0);
        account.setActive(true);
        
        Account savedAccount = accountRepository.save(account);
        // Publish account created event
        kafkaProducerService.sendAccountCreatedEvent(savedAccount);
        
        logger.info("Created default account for user: {}", userId);
        return savedAccount;
    }
    
    /**
     * Process a deposit transaction
     * 
     * @param accountId The account ID
     * @param amount The amount to deposit
     * @param transactionId The transaction ID
     */
    @Transactional
    public void processDeposit(Long accountId, Double amount, Long transactionId) {
        logger.info("Processing deposit: Account={}, Amount={}, Transaction={}", accountId, amount, transactionId);
        Account account = getAccountById(accountId);
        if (account != null) {
            double oldBalance = account.getBalance();
            account.setBalance(account.getBalance() + amount);
            accountRepository.save(account);
            
            logger.info("Updated account balance: Account={}, Old Balance={}, New Balance={}", 
                    accountId, oldBalance, account.getBalance());
            
            // Publish account updated event
            kafkaProducerService.sendAccountUpdatedEvent(account);
            
            // Publish transaction completed event
            kafkaProducerService.sendTransactionCompletedEvent(transactionId, "COMPLETED");
            
            logger.info("Processed deposit of {} to account {}", amount, accountId);
        } else {
            // Publish transaction failed event
            kafkaProducerService.sendTransactionCompletedEvent(transactionId, "FAILED");
            logger.error("Failed to process deposit: Account not found with ID: {}", accountId);
        }
    }
    
    /**
     * Process a withdrawal transaction
     * 
     * @param accountId The account ID
     * @param amount The amount to withdraw
     * @param transactionId The transaction ID
     */
    @Transactional
    public void processWithdrawal(Long accountId, Double amount, Long transactionId) {
        Account account = getAccountById(accountId);
        if (account != null) {
            if (account.getBalance() >= amount) {
                account.setBalance(account.getBalance() - amount);
                accountRepository.save(account);
                
                // Publish account updated event
                kafkaProducerService.sendAccountUpdatedEvent(account);
                
                // Publish transaction completed event
                kafkaProducerService.sendTransactionCompletedEvent(transactionId, "COMPLETED");
                
                logger.info("Processed withdrawal of {} from account {}", amount, accountId);
            } else {
                // Publish transaction failed event
                kafkaProducerService.sendTransactionCompletedEvent(transactionId, "FAILED");
                logger.error("Failed to process withdrawal: Insufficient funds in account {}", accountId);
            }
        } else {
            // Publish transaction failed event
            kafkaProducerService.sendTransactionCompletedEvent(transactionId, "FAILED");
            logger.error("Failed to process withdrawal: Account not found with ID: {}", accountId);
        }
    }
    
    /**
     * Process a transfer transaction
     * 
     * @param sourceAccountId The source account ID
     * @param destinationAccountId The destination account ID
     * @param amount The amount to transfer
     * @param transactionId The transaction ID
     */
    @Transactional
    public void processTransfer(Long sourceAccountId, Long destinationAccountId, Double amount, Long transactionId) {
        Account sourceAccount = getAccountById(sourceAccountId);
        Account destinationAccount = getAccountById(destinationAccountId);
        
        if (sourceAccount != null && destinationAccount != null) {
            if (sourceAccount.getBalance() >= amount) {
                // Deduct from source account
                sourceAccount.setBalance(sourceAccount.getBalance() - amount);
                accountRepository.save(sourceAccount);
                
                // Add to destination account
                destinationAccount.setBalance(destinationAccount.getBalance() + amount);
                accountRepository.save(destinationAccount);
                
                // Publish account updated events
                kafkaProducerService.sendAccountUpdatedEvent(sourceAccount);
                kafkaProducerService.sendAccountUpdatedEvent(destinationAccount);
                
                // Publish transaction completed event
                kafkaProducerService.sendTransactionCompletedEvent(transactionId, "COMPLETED");
                
                logger.info("Processed transfer of {} from account {} to account {}", 
                        amount, sourceAccountId, destinationAccountId);
            } else {
                // Publish transaction failed event
                kafkaProducerService.sendTransactionCompletedEvent(transactionId, "FAILED");
                logger.error("Failed to process transfer: Insufficient funds in source account {}", sourceAccountId);
            }
        } else {
            // Publish transaction failed event
            kafkaProducerService.sendTransactionCompletedEvent(transactionId, "FAILED");
            logger.error("Failed to process transfer: One or both accounts not found");
        }
    }
    
    /**
     * Generate a unique account number
     * 
     * @return A unique account number
     */
    private String generateAccountNumber() {
        return "ACC" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
}
