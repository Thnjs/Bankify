package com.bankify.accountservice.controller;

import com.bankify.accountservice.entity.Account;
import com.bankify.accountservice.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    private final AccountService accountService;

    @Autowired
    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @PostMapping
    public Account createAccount(@RequestBody Account account) {
        return accountService.createAccount(account);
    }

    @GetMapping("/{id}")
    public Account getAccountById(@PathVariable Long id) {
        return accountService.getAccountById(id);
    }

    @PutMapping("/{id}/updateBalance")
    public void updateBalance(@PathVariable Long id, @RequestParam Double amount) {
        accountService.updateBalance(id, amount);
    }
    
    @GetMapping("/user/{userId}")
    public List<Account> getAccountsByUserId(@PathVariable Long userId) {
        return accountService.getAccountsByUserId(userId);
    }
    
    @GetMapping
    public List<Account> getAllAccounts() {
        return accountService.getAllAccounts();
    }
    
    @GetMapping("/{id}/hasSufficientFunds")
    public boolean hasSufficientFunds(@PathVariable Long id, @RequestParam Double amount) {
        return accountService.hasSufficientFunds(id, amount);
    }
    
    @GetMapping("/number/{accountNumber}")
    public ResponseEntity<Account> getAccountByAccountNumber(@PathVariable String accountNumber) {
        Account account = accountService.getAccountByAccountNumber(accountNumber);
        if (account != null) {
            return ResponseEntity.ok(account);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/number/{accountNumber}/hasSufficientFunds")
    public boolean hasSufficientFundsByAccountNumber(@PathVariable String accountNumber, @RequestParam Double amount) {
        return accountService.hasSufficientFundsByAccountNumber(accountNumber, amount);
    }
    
    @PutMapping("/number/{accountNumber}/updateBalance")
    public ResponseEntity<Account> updateBalanceByAccountNumber(@PathVariable String accountNumber, @RequestParam Double amount) {
        try {
            accountService.updateBalanceByAccountNumber(accountNumber, amount);
            Account updatedAccount = accountService.getAccountByAccountNumber(accountNumber);
            return ResponseEntity.ok(updatedAccount);
        } catch (Exception e) {
            return ResponseEntity.status(500).build();
        }
    }
    
    /**
     * Delete all accounts associated with a specific user
     * @param userId The ID of the user whose accounts should be deleted
     * @return ResponseEntity with the number of accounts deleted
     */
    @DeleteMapping("/user/{userId}")
    public ResponseEntity<Map<String, Object>> deleteAccountsByUserId(@PathVariable Long userId) {
        try {
            int deletedCount = accountService.deleteAccountsByUserId(userId);
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Successfully deleted " + deletedCount + " account(s) for user " + userId);
            response.put("deletedCount", deletedCount);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to delete accounts for user " + userId);
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.status(500).body(errorResponse);
        }
    }
}
