package com.bankify.accountservice.service;

import com.bankify.accountservice.entity.Account;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
public class KafkaProducerService {
    private static final Logger logger = LoggerFactory.getLogger(KafkaProducerService.class);
    
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;
    
    @Value("${kafka.topics.account-created}")
    private String accountCreatedTopic;
    
    @Value("${kafka.topics.account-updated}")
    private String accountUpdatedTopic;
    
    @Value("${kafka.topics.transaction-completed}")
    private String transactionCompletedTopic;
    
    @Value("${kafka.topics.account-deleted}")
    private String accountDeletedTopic;
    
    @Autowired
    public KafkaProducerService(KafkaTemplate<String, String> kafkaTemplate, ObjectMapper objectMapper) {
        this.kafkaTemplate = kafkaTemplate;
        this.objectMapper = objectMapper;
    }
    

    public void sendAccountCreatedEvent(Account account) {
        try {
            Map<String, Object> event = new HashMap<>();
            event.put("accountId", account.getAccountId());
            event.put("userId", account.getUserId());
            event.put("accountNumber", account.getAccountNumber());
            event.put("accountType", account.getAccountType());
            event.put("balance", account.getBalance());
            event.put("active", account.getActive());
            event.put("timestamp", LocalDateTime.now().toString());
            event.put("eventType", "ACCOUNT_CREATED");
            
            String message = objectMapper.writeValueAsString(event);
            kafkaTemplate.send(accountCreatedTopic, account.getAccountId().toString(), message);
            logger.info("Account created event sent for account: {}", account.getAccountId());
        } catch (JsonProcessingException e) {
            logger.error("Error sending account created event: {}", e.getMessage());
        }
    }
    

    public void sendAccountUpdatedEvent(Account account) {
        try {
            Map<String, Object> event = new HashMap<>();
            event.put("accountId", account.getAccountId());
            event.put("userId", account.getUserId());
            event.put("accountNumber", account.getAccountNumber());
            event.put("accountType", account.getAccountType());
            event.put("balance", account.getBalance());
            event.put("active", account.getActive());
            event.put("timestamp", LocalDateTime.now().toString());
            event.put("eventType", "ACCOUNT_UPDATED");
            
            String message = objectMapper.writeValueAsString(event);
            kafkaTemplate.send(accountUpdatedTopic, account.getAccountId().toString(), message);
            logger.info("Account updated event sent for account: {}", account.getAccountId());
        } catch (JsonProcessingException e) {
            logger.error("Error sending account updated event: {}", e.getMessage());
        }
    }
    

    public void sendTransactionCompletedEvent(Long transactionId, String status) {
        try {
            Map<String, Object> event = new HashMap<>();
            event.put("transactionId", transactionId);
            event.put("status", status);
            event.put("timestamp", LocalDateTime.now().toString());
            
            String message = objectMapper.writeValueAsString(event);
            kafkaTemplate.send(transactionCompletedTopic, String.valueOf(transactionId), message);
            logger.info("Sent transaction completed event: {}", message);
        } catch (JsonProcessingException e) {
            logger.error("Error sending transaction completed event", e);
        }
    }
    

    public void sendAccountDeletedEvent(Account account) {
        try {
            Map<String, Object> event = new HashMap<>();
            event.put("accountId", account.getAccountId());
            event.put("accountNumber", account.getAccountNumber());
            event.put("userId", account.getUserId());
            event.put("timestamp", LocalDateTime.now().toString());
            
            String message = objectMapper.writeValueAsString(event);
            kafkaTemplate.send(accountDeletedTopic, message);
            logger.info("Sent account deleted event: {}", message);
        } catch (JsonProcessingException e) {
            logger.error("Error sending account deleted event", e);
        }
    }
}
