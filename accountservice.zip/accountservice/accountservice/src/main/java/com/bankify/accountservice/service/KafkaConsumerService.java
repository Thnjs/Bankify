package com.bankify.accountservice.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumerService {
    private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerService.class);
    
    private final AccountService accountService;
    private final ObjectMapper objectMapper;
    
    @Autowired
    public KafkaConsumerService(AccountService accountService, ObjectMapper objectMapper) {
        this.accountService = accountService;
        this.objectMapper = objectMapper;
    }
    

    @KafkaListener(topics = "${kafka.topics.user-created}", groupId = "${spring.kafka.consumer.group-id}")
    public void consumeUserCreatedEvent(String event) {
        logger.info("Consumed user created event: {}", event);
        try {
            JsonNode eventNode = objectMapper.readTree(event);
            Long userId = eventNode.get("userId").asLong();
            String username = eventNode.get("username").asText();
            
            // Create a default account for the new user
            accountService.createDefaultAccount(userId, username);
            logger.info("Created default account for user: {}", userId);
        } catch (JsonProcessingException e) {
            logger.error("Error processing user created event: {}", e.getMessage());
        } catch (Exception e) {
            logger.error("Error creating default account: {}", e.getMessage());
        }
    }
    

    @KafkaListener(topics = "${kafka.topics.transaction-created}", groupId = "${spring.kafka.consumer.group-id}")
    public void consumeTransactionCreatedEvent(String event) {
        logger.info("Consumed transaction created event: {}", event);
        try {
            JsonNode eventNode = objectMapper.readTree(event);
            Long accountId = eventNode.get("accountId").asLong();
            String transactionType = eventNode.get("transactionType").get("typeName").asText();
            Double amount = eventNode.get("amount").asDouble();
            Long transactionId = eventNode.get("transactionId").asLong();
            
            logger.info("Processing transaction: ID={}, Type={}, Account={}, Amount={}", 
                    transactionId, transactionType, accountId, amount);
            
            // Process the transaction based on its type
            if ("DEPOSIT".equals(transactionType)) {
                accountService.processDeposit(accountId, amount, transactionId);
            } else if ("WITHDRAWAL".equals(transactionType)) {
                accountService.processWithdrawal(accountId, amount, transactionId);
            } else if ("TRANSFER".equals(transactionType)) {
                Long destinationAccountId = eventNode.get("destinationAccountId").asLong();
                accountService.processTransfer(accountId, destinationAccountId, amount, transactionId);
            }
        } catch (JsonProcessingException e) {
            logger.error("Error processing transaction created event: {}", e.getMessage());
        } catch (Exception e) {
            logger.error("Error processing transaction: {}", e.getMessage());
        }
    }
}
